# 产物与保留文件

正式交付：src、dist、dist-demo/index.html、releases/field-lab-vue-0.1.1.tgz、skills/ui-endfield-motion。

## 当前入口未引用的旧构建文件

- `D:/uiux/dist-demo/assets/index-BfRa1hAK.js`
- `D:/uiux/dist-demo/assets/index-CSwfZfyY.js`
- `D:/uiux/dist-demo/assets/index-D7x6eULZ.css`
- `D:/uiux/dist-demo/assets/index-DwbxBWI1.css`
- `D:/uiux/dist-demo/assets/index-VQw5W1n0.js`

上述旧产物均保留，未删除。0.1.0 tarball 在 releases 与 skill assets 中保留作为历史版本。
