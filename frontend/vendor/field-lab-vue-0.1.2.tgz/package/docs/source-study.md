# 终末地参考观察与 FIELD UI 重建

来源：[《明日方舟：终末地》官网](https://endfield.hypergryph.com/)。观察日期为 2026-09-15 至 2026-09-16（Asia/Shanghai）。未复制原站代码，也未据截图推断其前端框架或 shader 实现。

## 实际观察

桌面 viewport 为 1280×720，实际访问首页、干员情报、世界观、影像与玩法介绍。加载过程与动画过程没有独立测时，不能将加载延迟全部称为设计动画。

- 首页：大幅主视觉，下载操作靠右下，左侧固定白色窄导航。
- 干员：浅色画布、巨大背景英文、黑色标题、局部黄色块、斜线纹理与层叠人物。点击导航后经历空白加载，再出现稳定内容。
- 世界观：深色画布、点云形体、环形刻度、细分割线与右侧文案。实际点击下一项，帝江号 1/6 变为锚点 2/6，点云与文案一起改变。证据：`evidence/reference-lore-01.png`、`evidence/reference-lore-02.png`。
- 影像：大幅背景叠加暗遮罩，底部前后卡片与较大的中间活动卡片。实际点击 next，干员叙事变为雪凇幽梦版本 PV，标题与页码更新。证据：`evidence/reference-media.png`。未播放或下载视频。
- 玩法：巨大 ENDFIELD 字样、主体图像加右侧黄色竖条、底部圆形前后按钮。实际从探索塔卫二 1/4 翻到小队协同作战 2/4，以 DOM 文本核对。证据：`evidence/reference-gameplay.png`。
- 窄屏 390×844：顶部 logo、操作区和菜单图标；公告改为竖向列表，保留黄色装饰带。证据：`evidence/reference-mobile.png`。未确认原站移动菜单完整展开及 touch 手势。

截图版权归原站权利人，仅作观察证据，不代表获得素材使用授权，不包含在 npm 组件包内。

## 设计约束

复杂画面集中在主视觉区域，正文与操作留出空间。黄色用于定位与状态；巨大标题和微小技术标记形成尺度差。浅色展示与深色沉浸区交替，颜色角色一致。

运动区分按钮反馈、内容切换和背景循环三种节奏。切换使用小幅移动、遮罩与渐显，避免所有层同时大幅移动。组件内容通过 props/slots 注入，解除游戏业务和原站资源的绑定。

## 自主实现的 tokens 与行为

以下为重建选择，**不是原站实测精确值**：

- 背景 `#eeefe9`，表面 `#fafbf6`，正文 `#23271f`，次要文字 `#666d60`，细线 `#cfd3c6`，强调色 `#d4ef37`。
- 深色场景背景 `#171c17`、正文 `#e8eddf`、次要文字 `#9fa894`、线条 `#3a4335`。
- 字体使用系统 sans-serif 与 monospace，不下载品牌字体；零圆角、1px 细线、正交网格为主，轮播箭头为圆形。
- 基础 duration 640ms，快速反馈 192ms，easing 为 `cubic-bezier(.22,1,.36,1)`。
- 入场从下方 28px 与 opacity 0 渐入；场景采用 out-in，进入位移 38px、退出 20px，两个阶段各 0.8 倍基础 duration，透明度使用 0.6 倍。
- 卡片 tilt 默认 6°，实际每轴约 ±3°，仅 mouse pointer 生效。reduced 与 touch 下静态展示。
- Canvas 点云 + SVG 刻度；core/orbit/beacon 为原创数学形体，未使用 WebGL、GSAP 或 Three.js。点云离屏、document hidden 与 reduced 时暂停；DPR 上限 2，density 上限 5000。

建议 duration 400–900ms、tilt 4–8°、点云 1200–3000 点；移动端可降低到 800–1600 点。可改变颜色、明暗、标题、素材与内容，保留层级、细线、网格和动效节奏。适合产品展示、科技品牌、科幻题材与作品集；正文不应套用极小装饰标记的字号。

## 可复用单元

- `FieldProvider` 统一主题与动态偏好；`RailNav` 和 `SectionHeading` 组织章节。
- `SceneSwitcher` 与 `TechTabs` 组织内容切换；`OrbitField` 提供原创点云。
- `TechButton`、`HoloCard` 提供反馈；`FieldDialog` 展示详情。
- `MotionReveal`、`ScrambleText`、`SignalTicker` 分别处理入场、解码与连续信号带。

HoloCard 精细 hover、ScrambleText、实验室 UI、显式焦点循环和 reduced 控制属于重建扩展，未声称原站具有完全相同的实现。原站精确 duration/easing、完整触屏表现、素材授权、Canvas/WebGL 内部实现与低端设备帧率仍未知。

运行入口：`src/lib/index.ts`（公开源码）、`src/lib/entry.ts`（构建）、`src/main.ts`（演示）。样式和 tokens 位于 `src/lib/styles.css`。接入见 README 和 API，验证见 `docs/verification.md`。原站截图与本地截图分别以 reference-/demo- 命名。
