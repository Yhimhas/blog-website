# FIELD UI

参考 [《明日方舟：终末地》官网](https://endfield.hypergryph.com/) 的工业视觉与交互节奏，独立实现的 Vue 3 动效组件库。支持 Vue JavaScript 和 TypeScript 项目。没有 React 适配层。

**12 个组件，零额外动效依赖。** 源码、演示页、ES module、类型声明与可本地安装的 npm tarball 一起交付。没有复制原站代码、角色图片、视频或品牌字体；原站截图只作为设计观察证据。

## 运行与构建

需要 Node.js 20.19+ 或 22.12+。

```powershell
cd D:\uiux
npm install
npm run dev
```

打开 http://127.0.0.1:5173 。演示包括场景轮播、组件搜索与 API 弹层、实时动效参数、Vue JS / TS 示例与代码复制。

```powershell
npm run build       # 类型检查 + library + demo
npm test            # 先 build，测试的是实际产物
npm run pack:local  # releases/field-lab-vue-0.1.1.tgz
```

`dist/` 是库产物，`dist-demo/` 是演示站。构建配置为 `emptyOutDir: false`，不会清空旧文件。重新构建产生的旧 hash 文件会保留，详见 [产物记录](docs/artifacts.md)。

## 在你的项目中调用

将 `releases/field-lab-vue-0.1.1.tgz` 复制到目标 Vue 项目，然后安装：

```sh
npm install ./field-lab-vue-0.1.1.tgz
```

组件包尚未发布到 npm，不能直接从 registry 安装 `@field-lab/vue`。

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { FieldProvider, TechButton, SceneSwitcher } from '@field-lab/vue'
import '@field-lab/vue/style.css'

const current = ref(0)
const scenes = [
  { id: 'core', title: '协议核心', description: '让内容有序展开。' },
  { id: 'orbit', title: '轨道阵列', description: '探索下一个场景。' }
]
</script>

<template>
  <FieldProvider :duration="640" accent="#d4ef37">
    <SceneSwitcher v-model="current" :items="scenes" />
    <TechButton @click="current = (current + 1) % scenes.length"> 下一个场景 </TechButton>
  </FieldProvider>
</template>
```

Vue JS 只需去掉 `lang="ts"`，其余用法相同。组件按名称导入，支持 tree shaking；Vue 是 peer dependency，最低版本 3.5。样式只提供一份公共 CSS，不改动宿主页面的 reset、body、字体或全局 `:root`。所有组件应置于 `FieldProvider` 内；组件样式使用 `f-` 前缀，主题变量使用 `--f-` 前缀。

## 组件

- **布局**：`FieldProvider`、`RailNav`、`SectionHeading`。
- **交互**：`SceneSwitcher`、`TechTabs`、`TechButton`、`HoloCard`、`FieldDialog`。
- **动效**：`OrbitField`、`MotionReveal`、`SignalTicker`、`ScrambleText`。

完整 props、events、slots 和限制见 [API 文档](docs/api.md)，页面中也可以搜索组件并复制片段。可组合的类型 `SceneItem`、`TabItem`、`NavItem` 与 composables `useFieldMotion`、`useReducedMotion` 一并导出。

## 主题与动态偏好

```vue
<FieldProvider theme="dark" accent="#87bbed" :duration="800" :reduced="false" :paused="false">
  <!-- 放入组件 -->
</FieldProvider>
```

系统 `prefers-reduced-motion` 优先于页面选项。`reduced` / `paused` 任一开启时，停止循环点云与文字解码，取消位移和 hover 倾斜，保留操作功能。`duration` 为基础时长，场景退出与进入阶段分别按比例计算，整个场景切换不等于一个基础时长。

`OrbitField` 在不可见和 document hidden 时停止 requestAnimationFrame；Canvas DPR 上限 2，density 上限 5000。默认图形是自主实现的点云形体，可替换 `SceneSwitcher` slot 中的图形为自己的合法图片、视频或模型。

## 文件与追溯

- `src/lib/`：可复用源码、tokens 与组件；`src/App.vue` 和 `src/demo.css`：演示工程。
- [设计观察与重建说明](docs/source-study.md)：原站实际观察、未确认项、重建参数。
- [验证记录](docs/verification.md)：构建、测试、浏览器覆盖与限制。
- `docs/evidence/`：原站观察截图与本地演示截图。
- `scripts/save-vault.mjs`：将当前交付保存为 ui-vault 的新修订，保留原索引和历史，不删除文件。

默认素材库：`C:\Users\lin\Documents\Codex\ui-vault-library`。条目 ID：`endfield-industrial-motion`。`npm run vault:save` 写入新修订，而不是覆盖旧修订。

代码使用 MIT License。第三方参考截图的版权归原权利人，未获得独立再分发授权，不随 npm 组件包分发。
