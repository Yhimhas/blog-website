# 验证记录

日期：2026-09-16（Asia/Shanghai）。最终构建：通过。

## 构建与公开包

- Node.js 20.19.5；Vue 3.5.42；Vite 7.3.6；构建版本锁定在 package-lock.json。
- `npm run build`：vue-tsc 类型检查、Vite library 与演示生产构建全部通过。
- 组件库 `dist/field-ui.js` 25.41 KB，gzip 7.88 KB；CSS 14.02 KB，gzip 3.77 KB。Vue 作为 external peer，不包含在该体积中。
- `npm test`：6 项测试全部通过。测试从包自身导出路径 `@field-lab/vue` 导入，覆盖 12 个组件的 SSR 渲染、空轮播/越界/NaN、Tabs 禁用与空输入、实例 ARIA id 唯一性、loading 原生禁用、Provider 时长校正和服务器可见输出。
- 声明入口 `dist/types/index.d.ts` 与 CSS export `@field-lab/vue/style.css` 已生成，公开类型入口不引用未生成的源码 CSS。

## 浏览器交互

使用 Codex In-app Browser，初始开发服务为 127.0.0.1:5173，最终生产构建为 127.0.0.1:4173。

- 桌面 1280×720 和 1440×900 检查首屏、深色场景、组件目录与实验区域；完成截图检查。
- Tabs：点击选中、ArrowRight 切换并更新 aria-selected；组件实例拥有独立关联 id。
- 场景：前后翻页、连续快速点击、End 跳到最后一项，最终主体与页码收敛到正确项。生产构建从核心切到轨道阵列成功。
- 目录：搜索无匹配时展示空态，重置恢复 6 项精选；展开后出现全部 12 个组件；API 弹层显示相应 props 与代码。
- 剪贴板：实际复制 HoloCard 代码并读取核对；配置代码复制包含当前 duration。Vue JS 切换后的代码正确去掉 lang="ts"。
- 弹层：打开聚焦关闭按钮；Shift+Tab 从首项回到末项，Tab 从末项回到首项；Escape 关闭后归还到触发按钮。显式焦点循环修复了原生边界会把焦点移向浏览器区域的问题。
- 动效实验：duration 滑块至 1200 后 Provider CSS 变量更新；冰川蓝更新强调色；减少动态后根状态为 reduced，卡片 transform=none、点云 data-static、ticker animation=none。
- Loading：同步按钮进入 disabled/loading，模拟同步完成后恢复按钮并显示成功反馈。它只是本地演示，不发送网络请求。
- Hover：在实验卡片上实际移动/点击后，记录到非零旋转值与光斑坐标。
- 移动导航：390×844 下展开、点击“概览”、菜单自动收起；已检查相应可访问状态。
- 窄屏溢出：修复接入区 CSS Grid 默认 min-width 导致的溢出。390px 时 clientWidth=scrollWidth=375；320px 时二者均为 305（均扣除浏览器滚动条宽度）。代码在自己的 pre 内滚动，页面没有横向溢出。
- 首轮开发页无运行错误。格式化期间曾出现 Vue 模板解析错误，已通过提取具名事件函数修复；最终完整构建通过。旧开发日志仍保留，不代表生产页面错误。

## 证据

- `evidence/demo-desktop-1440.png`：最终生产首屏。
- `evidence/demo-scenes-1440.png`：最终生产场景。
- `evidence/demo-mobile-390.png`：修复后移动首屏。
- `evidence/demo-components-1440.png`：最终组件目录。
- 原站观察截图使用 reference- 前缀，详见 source-study.md。

## 仍未验证

真实触屏 swipe、Safari/Firefox、完整 Nuxt hydration、嵌套 dialog/iframe/Shadow DOM 焦点、极低端 GPU 和大规模同时挂载性能未测试。实际浏览器 reduced 验证使用组件开关，没有修改用户操作系统设置。没有做逐帧对照，不能把该重建称作原站动画的精确复制。

React 未实现；Vue JS 与 TS 使用同一 Vue 包。原站人物、品牌字体、视频和内部 WebGL 资源不在交付包中。
