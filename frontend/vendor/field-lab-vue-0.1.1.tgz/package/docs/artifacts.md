# 产物与保留文件

没有删除任何文件。

## 正式交付

- `src/`：组件库及演示源码。
- `dist/`：最新 ES module、CSS、类型声明；npm 包使用这里的文件。
- `dist-demo/index.html`：最新生产演示入口，引用 `index-VQw5W1n0.js` 和 `index-D7x6eULZ.css`。
- `releases/field-lab-vue-0.1.0.tgz`：本地安装包。
- `docs/`：接入 API、来源观察、验证记录、截图。
- `tests/`：可重复运行的 SSR 与公开接口测试。
- `scripts/`：本地打包与 ui-vault 新修订保存工具。

## 不再使用但已保留的旧构建产物

为遵守“不删除文件”，Vite 设置 `emptyOutDir: false`。以下两个早期构建 hash 文件没有被最终 index.html 引用，也不进入组件 npm 包：

1. `D:\uiux\dist-demo\assets\index-CSwfZfyY.js`（118244 bytes）。
2. `D:\uiux\dist-demo\assets\index-DwbxBWI1.css`（43823 bytes）。

它们不影响运行。是否清理由用户决定，本任务未执行删除。

`node_modules/`、`package-lock.json` 与包管理缓存是正常开发依赖，不属于丢弃试验项目。没有另外生成无用 demo 工程或下载第三方媒体。
