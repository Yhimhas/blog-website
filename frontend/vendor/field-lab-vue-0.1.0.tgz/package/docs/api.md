# FIELD UI API

组件均从 `@field-lab/vue` 按名称导入。样式路径为 `@field-lab/vue/style.css`。示例默认在 `FieldProvider` 内运行。JS 与 TS 组件接口相同。

## FieldProvider

主题与 motion context 的入口。默认渲染一个 `div.f-root`，自定义 class、style、id 会透传到根节点。

- `duration?: number = 640`：基础时长，毫秒。自动限制到 120–2000。
- `accent?: string = '#d4ef37'`：合法 CSS color。
- `theme?: 'light' | 'dark' = 'light'`。
- `reduced?: boolean = false`、`paused?: boolean = false`：任意一个为 true 时关闭非必要动态；系统 reduced motion 总是生效。
- 默认 slot 提供 `{ reduced: boolean }`。

可覆盖变量：`--f-bg`、`--f-surface`、`--f-ink`、`--f-muted`、`--f-line`、`--f-ease`、`--f-mono`、`--f-sans`。颜色、时长优先使用 props。嵌套 Provider 的设置只影响自身子树。

## TechButton

- `variant?: 'solid' | 'accent' | 'outline' | 'ghost' = 'solid'`。
- `disabled?: boolean = false`、`loading?: boolean = false`：任意为 true 都会使用原生 disabled；loading 显示 spinner 与 `aria-busy`。
- `arrow?: boolean = true`；`type?: 'button' | 'submit' | 'reset' = 'button'`。
- 默认 slot：按钮文本。`@click`、`name`、`form`、`aria-label` 等原生属性与事件透传。

按钮不是链接，导航请使用链接或在 click 中调用自己的 router。没有内建网络请求。

## RailNav

`items: NavItem[]` 必填。`NavItem` 包含 `id: string`、`label: string`、`symbol?: string`。`id` 对应页面 section 的锚点，必须唯一；symbol 为短文本图标。`active?: string` 控制 `aria-current`，`brand?: string = 'F/'`。

`navigate(id)` 在导航时发出；实际链接使用原生 `href="#id"`。组件不劫持滚轮，不自行执行 scroll spy。演示工程使用 IntersectionObserver 更新 active。

桌面固定侧栏宽 76px、展开后宽 196px；<=760px 转为 60px 高的顶部导航。宿主需预留左/顶部空间，示例：

```css
.page {
  margin-left: 76px;
}
@media (max-width: 760px) {
  .page {
    margin-left: 0;
    padding-top: 60px;
  }
}
```

点击菜单按钮展开/收起，Escape 收起，选择章节后收起。不要给锚点 id 放入空格或 `#`。

## SectionHeading

`title: string` 必填。可选 `index = '01'`、`eyebrow`、`description`、`level: 1 | 2 | 3 = 2`。默认 slot 在 description 后面补充内容。请按页面层级选择 level。

## SceneSwitcher

`items: SceneItem[]` 必填。数据结构：

```ts
interface SceneItem {
  id: string // 必须唯一，作为过渡 key
  title: string
  kicker?: string
  description?: string
}
```

- `v-model: number = 0`：受控索引。索引越界、负数、NaN 会在显示端校正。使用时必须接收 `update:modelValue`（通常直接使用 v-model），否则用户操作不会保存新索引。
- `label?: string = '场景切换'`。
- `change(item, index)`：操作选择新条目时发出；外部直接改变 modelValue 不重复触发 change。
- 默认 slot：`{ item, index }`，可自定义图像、标题与内容；不提供 slot 时展示 kicker/title/description。
- `empty` slot：items 为空时显示，默认“暂无场景”。一项时翻页按钮禁用。

前后翻页循环；方向键、Home、End 生效，输入框中不接管键盘。触摸滑动要求水平方向超过 50px，且大于垂直位移的 1.4 倍。默认保留垂直滚动。

过渡使用 Vue Transition 的 out-in 模式。退出为基础 duration 的 0.8 倍，进入同样为 0.8 倍；透明度使用 0.6 倍。快速操作会收敛到最新索引，切换途中页码可能先于主体更新。不同高度内容会产生布局高度变化；需要固定画幅时给 slot 容器设置固定高度或 min-height。

## OrbitField

- `variant?: 'core' | 'orbit' | 'beacon' = 'core'`。
- `density?: number = 1800`，200–5000 点。
- `color?: string = '#303a2b'`、`accent?: string = '#a1bd16'`。这是 Canvas 绘制颜色，独立于 Provider 的 CSS 主题；暗色背景请显式设置浅色 color。
- `label?: string`：提供时暴露为 image 角色；省略时作为装饰 `aria-hidden`。

宽高依赖父容器，通常显式设置 `style="height:420px"`。SVG 标记、环形刻度和 Canvas 点云在同一容器内，不能交互。Canvas 不支持时保留 SVG 刻度。点云计算约按 30fps 调度，未做所有设备的帧率承诺；requestAnimationFrame 随离屏、页面隐藏、reduced 停止，卸载时清理 Observer 与监听器。

## HoloCard

`tilt?: number = 6`，限制到 0–12°；实际轴旋转为输入幅度的一半。默认 slot 为任意内容。根节点为 `article`，卡片本身不模拟 button；可操作内容请使用 button/link。

鼠标移动时轻微透视与径向光斑跟随。触摸和非 mouse pointer 不启用倾斜。离开、取消 pointer 或 reduced 时复位。卸载时取消待执行动画帧。

## TechTabs

`items: TabItem[]` 与 `v-model: string` 必填。`TabItem` 为 `{ id: string; label: string; disabled?: boolean }`。`label?: string = '内容选项'`。

默认 slot 提供 `{ active: string | undefined }`。方向键循环跳过禁用项，Home/End 选中首尾可用项。使用 `role=tablist/tab/tabpanel`，同页实例拥有独立 ARIA id。非法/禁用 modelValue 在显示上回退到首个可用项；所有项禁用或为空时 active 为 undefined。

Tabs 不缓存你的内容组件，slot 内容生命周期由宿主的 v-if/v-show 决定。

## MotionReveal

`delay?: number = 0`（0–2000ms），`distance?: number = 28`（0–120px），`once?: boolean = true`。默认 slot 是待展示内容。

IntersectionObserver threshold 为 0.08；once=true 首次进入后不再隐藏，once=false 可以重复触发。SSR 初始内容保持可见，mounted 后建立观察。没有 Observer 时保持可见。焦点进入时也会展示内容，避免键盘操作隐形区域。

## FieldDialog

`v-model: boolean`、`title: string` 必填，`eyebrow?: string` 可选。默认 slot：正文；`footer` slot：底部操作。

使用 HTML dialog/showModal。打开时聚焦关闭按钮，Tab/Shift+Tab 在可见的可聚焦元素中循环；Escape、关闭按钮与背景点击关闭，关闭后尝试恢复之前的焦点。dialog 最大高度 85dvh，长内容内部滚动。

支持现代 Chromium、Safari 和 Firefox 的原生 dialog；不包含旧浏览器 polyfill。SSR 不调用 showModal，客户端 mounted 后同步打开状态。入场动画已实现，关闭为立即关闭。嵌套复杂弹层、iframe 内焦点、Shadow DOM 焦点未验证。

## SignalTicker

`items: string[]` 必填；`seconds?: number = 32`（8–120秒）。内容复制一次实现循环，第二份从读屏隐藏。hover 暂停；reduced 时取消移动，显示一份可换行内容。每组内容总宽度应至少覆盖容器，否则循环可能出现留白。

## ScrambleText

`text: string` 必填，`trigger?: string | number = 0`。text/trigger 改变或首次 mounted 时解码一次。使用 Provider 的基础 duration；重复触发会取消上一次动画。屏幕阅读器读取完整 text；reduced 直接显示最终文字。

## Composables 与 SSR

`useFieldMotion()` 返回 `{ reduced: ComputedRef<boolean>, duration: ComputedRef<number> }`。在 setup 中调用，没有 Provider 时会读取系统 reduced 并使用 640ms。`useReducedMotion()` 返回响应系统媒体查询的 Ref<boolean>。

公开组件已通过无浏览器全局对象的 SSR 渲染检查。完整 Nuxt/SSR hydration 尚未测试；DOM 与 Canvas 的实际初始化均在 mounted 内。
